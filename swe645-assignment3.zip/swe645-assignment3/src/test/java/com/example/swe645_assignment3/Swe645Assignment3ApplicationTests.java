package com.example.swe645_assignment3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Swe645Assignment3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
